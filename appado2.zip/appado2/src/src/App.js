/** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
* SENAC - TADS - Programacao Web *
* ADO #02 Trabalhando As Rotas e LINKS *
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
* Nome : Guilherme Moura de Souza *
* Nome : Beatriz Gomes Feliciano  *
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
import RoutesApp from "./routes";


function App() {
  return (
    <RoutesApp/>
  );
}

export default App;
